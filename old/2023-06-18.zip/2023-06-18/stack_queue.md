// array: continuous / 不可拆
// linked list: node by node / 可拆



## stack: FILO

1. push
2. pop
3. top

```cpp

class Stack:
private:
    int arr[100];




```


## queue: FIFO

1. push
2. pop
3. top


// vector: dynamic array


